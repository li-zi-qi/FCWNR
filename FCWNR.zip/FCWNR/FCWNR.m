function alpha = FCWNR(X, y, param, trls)

    lambda = param.lambda;
    gamma = param.gamma;
    mu = param.mu;
    maxIter = param.maxIter;
    
    class_num = length(unique(trls));
    [m, n] = size(X);
    
    alpha = zeros(n, 1);
    F = zeros(m, class_num);
    z = alpha;
    delta = alpha;
    
    sumXiTXi = zeros(n);
    for ci = 1:class_num
        index = trls == ci;
        Xi = zeros(m, n);
        Xi(:, index) = X(:, index);
        sumXiTXi = sumXiTXi + (Xi' * Xi);
    end

    P =  X' * X + lambda * sumXiTXi + 0.5 * mu * eye(n);
    XTy = X' * y;
    
    iter = 0;
    while iter < maxIter
        
        iter = iter + 1;
        
        temp = zeros(n, 1);
        temp1 = zeros(n, 1);
        for ci = 1:class_num
            index = trls == ci;
            temp(index) = norm(F(:, ci)).^2;
            Xi = zeros(m, n);
            Xi(:, index) = X(:, index);
            temp1 = temp1 + Xi' * (y - F(:, ci));
        end
        
        alpha = (P + gamma * diag(temp)) \ (XTy + lambda * temp1 + 0.5 * mu * z + 0.5 * delta);
        
        for ci = 1:class_num
            index = trls == ci;
            F(:, ci) = ((lambda + gamma * norm(alpha(index)).^2) * eye(m)) \ (lambda * ( y - X(:, index) * alpha(index)));
        end
        
        z = max(0, alpha - delta / mu);
        delta = delta + mu * (z - alpha);
    end
end
