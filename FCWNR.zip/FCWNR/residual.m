function residuals = residual(X, y, alpha, trls)

    class_num = length(unique(trls));
    residuals = zeros(1, class_num);
    
    for i = 1:class_num
        index = i == trls;
        residuals(i) = norm(y - X(:, index) * alpha(index));
    end
    
end
