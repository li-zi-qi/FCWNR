clear
clc

load('data/AR.mat');

%--------------------------------------------------------------------------

Tr_DAT = double(NewTrain_DAT);
trls = trainlabels;
Tt_DAT = double(NewTest_DAT);
ttls = testlabels;

train_tol = size(Tr_DAT, 2);
test_tol = size(Tt_DAT, 2);

%--------------------------------------------------------------------------

param.lambda = 1e-4;
param.gamma = 1;
param.mu = 1e-2;

% dim = 54, lambda = 0.000100, gamma = 1.000000, mu = 0.010000, acc = 85.55
% dim = 120, lambda = 0.000100, gamma = 1.000000, mu = 0.010000, acc = 91.99
% dim = 300, lambda = 0.010000, gamma = 0.001000, mu = 0.010000, acc = 94.28

param.maxIter = 5;

%--------------------------------------------------------------------------

dim = 54;

[disc_set, disc_value, Mean_Image]  =  Eigenface_f(Tr_DAT, dim);
tr_dat = disc_set' * Tr_DAT;
tt_dat = disc_set' * Tt_DAT;
tr_dat = normc(tr_dat);
tt_dat = normc(tt_dat);

X = tr_dat;
id = zeros(1, test_tol);

parfor i = 1:test_tol

    y = tt_dat(:, i);

    alpha = FCWNR(X, y, param, trls);

    residuals = residual(X, y, alpha, trls);

    [~, index] = min(residuals);

    id(i) = index;
end

cornum = sum(id == ttls);
acc = cornum / length(ttls);

fprintf('dim = %d, lambda = %f, gamma = %f, mu = %f, acc = %.2f\n', dim, param.lambda, param.gamma, param.mu, acc * 100);
